package pe.edu.upc.s3155_uwork4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3155Uwork4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
