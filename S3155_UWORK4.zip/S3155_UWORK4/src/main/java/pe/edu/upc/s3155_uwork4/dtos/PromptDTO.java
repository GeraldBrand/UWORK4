package pe.edu.upc.s3155_uwork4.dtos;

public class PromptDTO {
    private String prompt;

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }
}